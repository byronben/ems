<?php include "../includes/session.php"; ?>
<!DOCTYPE HTML>
<html>
<head>
	<?php include "header.php"; ?>

	<!-- For table -->
	<link rel="stylesheet" type="text/css" href="../css/table-style.css" />
	<link rel="stylesheet" type="text/css" href="../css/basictable.css" />
	<script type="text/javascript" src="../js/jquery.basictable.min.js"></script>
	<!-- For table -->

	<!-- For autocomplete -->
	<script type="text/javascript" src="../js/jquery-1.4.2.min.js"></script>
	<script type="text/javascript" src="../js/jquery.autocomplete.js"></script>
	<!-- For autocomplete -->

	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/clocklet@0.2.6/css/clocklet.min.css">
	<script src="https://cdn.jsdelivr.net/npm/clocklet@0.2.6"></script>
	<!-- timepicker -->

	<!---datepicker-->
	<?php //include "datepicker_css_js.php"; ?>
	<?php include "new_datepicker.php"; ?>
</head>

<body>

<div class="page-container">
<!--/content-inner-->
<div class="left-content">
	<div class="mother-grid-inner">
		<?php include "header_panel.php"; ?>

		<ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php">Home</a><i class="fa fa-angle-right"></i>Meetings
            <i class="fa fa-angle-right"></i>Check Attendance</li>
		</ol>
		
		<?php
            include "../includes/connect_db.php";
            $id = (isset($_GET['id']) ? $_GET['id'] : null);
			$title =(isset($_POST['title']) ? $_POST['title'] : null);
			$venue =(isset($_POST['venue']) ? $_POST['venue'] : null);
			$from_date =(isset($_POST['from_date']) ? $_POST['from_date'] : null);
			$to_date =(isset($_POST['to_date']) ? $_POST['to_date'] : null);
			$start_time =(isset($_POST['start_time']) ? $_POST['start_time'] : null);
			$end_time =(isset($_POST['end_time']) ? $_POST['end_time'] : null);
			$agenda =(isset($_POST['agenda']) ? $_POST['agenda'] : null);

            $info_query = "SELECT * FROM meeting WHERE meeting_id = '".$id."'";
            $info_result = mysqli_query($con, $info_query);
            $info_row = mysqli_fetch_assoc($info_result);

			$q_file = "SELECT fileName FROM documents WHERE meeting_id = '$id' ";
			$r_file = mysqli_query($con, $q_file);
			$info_file = mysqli_fetch_assoc($r_file);
			$fileName = $info_file['fileName'];

			$action =(isset($_POST['submit']) ? $_POST['submit'] : null);
			if($action != null) {		

				$q_update= "UPDATE meeting SET title = '$title', venue = '$venue', from_date = '$from_date', to_date = '$to_date', start_time = '$start_time', end_time='$end_time', agenda = '$agenda' WHERE meeting_id = '$id' ";
				$result=mysqli_query($con, $q_update);
				if($result) {
                    echo"<script type='text/javascript'>alert('Successfully updated meeting ".$id."!')</script>";
                    // header("Refresh:0");							
				}
				else {
					echo "<font style='color:red'>Unable to update meeting !</font><br><br>";		
				}
			}
		?>
		<div class="w3-agile-chat">
				<div class="charts">
					<div class="col-adjust-10">
						<div class="charts-grids widget">
							<h4 class="title">Meeting Details</h4>

                            <form action="meeting_details.php?id=<?php echo $id ?>" method="post">
                                <div class="vali-form">
									<div class="col-md-6 form-group1">
										<label class="control-label">Meeting Title</label>
										<input type="text" name="title" placeholder="Meeting Title" value="<?php echo $info_row['title'] ?>" disabled>
									</div>
									<div class="col-md-6 form-group1">
										<label class="control-label">Venue</label>
										<input type="text" name="venue" placeholder="Venue" value="<?php echo $info_row['venue'] ?>" disabled>
									</div>
                                	<div class="clearfix"></div>
								</div>

								<div class="vali-form vali-form1">
									<div class="col-md-6 form-group1">
										<label class="control-label">From Date</label>
										<input type="text" id="from" name="from_date" value="<?php echo $info_row['from_date']; ?>" disabled>
									</div>

									<div class="col-md-6 form-group1">
										<label class="control-label">To Date</label>
										<input type="text" id="to" name="to_date" value="<?php echo $info_row['to_date']; ?>" disabled>
									</div>
                                	<div class="clearfix"> </div>
								</div>

								<div class="vali-form vali-form1">
									<div class="col-md-6 form-group1">
										<label class="control-label">Start Time</label>
										<input data-clocklet="format: h:mm a" name='start_time' value= "<?php echo $info_row['start_time'] ?>" disabled/>
	                                </div>

	                            	<div class="col-md-6 form-group1">
										<label class="control-label">End Time</label>
										<input data-clocklet="format: h:mm a" name='end_time' value= "<?php echo $info_row['end_time'] ?>" disabled/>
	                            	</div>

	                            	<div class="clearfix"> </div>
                                </div>

                                <div class="vali-form vali-form1">
									<div class="col-md-6 form-group1">
									<label class="control-label">Agenda</label>
									<textarea name="agenda" placeholder="Agenda" disabled><?php echo $info_row['agenda'] ?></textarea>
                                	</div>

                                    <div class="col-md-6 form-group1">
									<label class="control-label">File for Reference</label>
									<div class="clearfix"><br/> </div>
									<?php 
									if($fileName!=null){
										echo "<a target='_blank' href='documents/$fileName'><span class='glyphicon glyphicon-eye-open'></span>&nbspView Uploaded File</a>";
									 }
									 else{
										 ?><input type="file" name="fileToUpload" id="fileToUpload" disabled><?php
									 }
									?>
									
                                	</div>
                                </div>

                                <div class="clearfix"><br/> </div>
								<div class="clearfix"><br> </div>
                            
                            	<!--Extension -->

	                        	<h2>Attendees</h2>
								<table id="table">

								<thead>
									<tr>
									<th>No.</th>
									<th>Staff ID</th>
									<th>Name</th>
									<th>Role</th>
									<th>Attendance Status</th>
									</tr>
								</thead>

								<tbody>
									<?php
										include "../includes/connect_db.php";
										$id = (isset($_GET['id']) ? $_GET['id'] : null);
										$query = "SELECT * FROM `attendees` WHERE meeting_id = $id";
										$result = mysqli_query($con, $query); 
										if(mysqli_num_rows($result) == 0) {
											echo '<tr class="odd gradeX"><td colspan="8">Record not found</td></tr>';                     
										}
										$i=0;
										while ($row = mysqli_fetch_assoc($result)){
									?>
									<tr>
									<td><?php echo $i+1 ?></td>
									<td><?php $staffid=$row['user_id'];
									echo $staffid; ?></td>
									<?php 
										$sub_query = "SELECT * FROM `staff` where user_id = $staffid ";
										$sub_result = mysqli_query($con, $sub_query);
										$sub_row = mysqli_fetch_assoc($sub_result);
									?>
									<td><?php echo $sub_row['first_name']," ", $sub_row['last_name'] ?></td>
									<td><?php echo $sub_row['role']; ?></td>
									<td><a href="meeting_details_remove_attendee.php?id=<?php echo $row['attendee_id']; ?>&mid=<?php echo $id?>" class="btn btn-warning">Remove</a></td>
									</tr>
									<?php $i+=1; } ?>
								</tbody>
								</table>

								<br>

	                        	<!--End Extension -->
                                <div class="col-md-12 form-group">
                                    <a href="index.php" class="btn btn-info" name="back">Back</a>
                                    <button class="btn btn-warning" type="submit" name="submit" value="submit">Confirm</button>
                                </div>
                            <div class="clearfix"> </div>
                        </form>

                        	
						</div>
					</div>			
					<div class="clearfix"> </div>	
				</div>
			</div>
				
<!--script for autocomplete-->
<script> 
jQuery(function(){ 
	$("#search").autocomplete("search_staff.php");
});
</script>
<!--script for autocomplete-->

<?php include "import_js.php"; ?>

</body>
</html>