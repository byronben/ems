<?php include "../includes/session.php"; ?>
<!DOCTYPE HTML>
<html>
<head>
	<title>EMS</title>
	<link rel="icon" type="image/ico" href="../images/paper.ico">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="keywords" content="Pooled Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
	Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
	<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
	<!-- Bootstrap Core CSS -->
	<link href="../css/bootstrap.min.css" rel='stylesheet' type='text/css'/>
	<!-- Custom CSS -->
	<link href="../css/style.css" rel='stylesheet' type='text/css'/>
	<link rel="stylesheet" href="css/morris.css" type="text/css"/>
	<!-- Graph CSS -->
	<link href="../css/font-awesome.css" rel="stylesheet"> 
	<!-- jQuery -->
	<script src="../js/jquery-2.1.4.min.js"></script>
	<!-- //jQuery -->
	<!-- chart -->
	<script src="../js/Chart.js"></script>
	<!-- //chart -->
	<link href='//fonts.googleapis.com/css?family=Roboto:700,500,300,100italic,100,400' rel='stylesheet' type='text/css'/>
	<link href='//fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'/>
	<!-- lined-icons -->
	<link rel="stylesheet" href="../css/icon-font.min.css" type='text/css'/>
	<!-- //lined-icons -->
</head>

<body>

<div class="page-container">
<!--/content-inner-->
<div class="left-content">
	<div class="mother-grid-inner">
		<!--header start here-->
		<div class="header-main">
			<div class="profile_details w3l">		 
				<ul>
					<li class="dropdown profile_details_drop">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
							<div class="profile_img">	
								<span class="prfil-img"><img src="../images/in4.jpg" alt=""> </span> 
								<div class="user-name">
									<p><?php echo $first_name ?></p>
									<span>Member</span>
								</div>
								<i class="fa fa-angle-down"></i>
								<i class="fa fa-angle-up"></i>
								<div class="clearfix"></div>	
							</div>	
						</a>
						<ul class="dropdown-menu drp-mnu">
							<li> <a  data-toggle="modal" data-target=".bs-example-modal-sm"><i class="fa fa-sign-out"></i> Logout</a> </li>
						</ul>
					</li>
				</ul>
			</div>
						
			<div class="clearfix"> </div>		
		</div>
		<!--header end here-->

		<ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php">Home</a>
            	<i class="fa fa-angle-right"></i>Edit Profile
            </li>
		</ol>
		
		<?php
			include "../includes/connect_db.php";
			$user_id =$staffid;

			$q_details = "SELECT * FROM staff WHERE user_id = '$staffid'";
			$result = mysqli_query($con, $q_details);
			$row = mysqli_fetch_assoc($result);

			
			$first_name =(isset($_POST['firstname']) ? $_POST['firstname'] : null);
			$last_name =(isset($_POST['lastname']) ? $_POST['lastname'] : null);
			$email =(isset($_POST['email']) ? $_POST['email'] : null);
			$mobile_no =(isset($_POST['mobile_no']) ? $_POST['mobile_no'] : null);
			$password =(isset($_POST['password']) ? $_POST['password'] : null);
			$con_password = (isset($_POST['con_password']) ? $_POST['con_password'] : null);
			// $role =(isset($_POST['role']) ? $_POST['role'] : null);
		
			$action =(isset($_POST['submit']) ? $_POST['submit'] : null);
			if($action != null) {
																				
				if($password != $con_password) {
					echo "<font style='color:red'>Passwords do not match !</font><br><br>";
				}

				else {
					$q_update= "UPDATE `staff` SET first_name = '$first_name', last_name = '$last_name', email = '$email', mobile_number = '$mobile_no', password = '$password' WHERE user_id = $user_id";
					echo $q_update;
					$result = mysqli_query($con, $q_update)or die(mysqli_error($con));
					
					if($result) {
						echo"<script type='text/javascript'>alert('Successfully updated this user !')</script>";
						$_SESSION["first_name"] = $first_name;
						header("Location:profile_update.php");																
					}
					else {
						echo "<font style='color:red'>Unable to update !</font><br><br>";		
					}
				}
			}
		?>
		<div class="w3-agile-chat">
				<div class="charts">
					<div class="col-adjust-10">
						<div class="charts-grids widget">
							<h4 class="title">EMS</h4>

                            <form action="profile_update.php" method="post">
                                <div class="vali-form">
	                                <div class="col-md-6 form-group1">
	                                	<input type="text" name="staffid" placeholder="Staff ID" value= "<?php echo $row['user_id']?>" hidden>
	                                    <label class="control-label">First Name</label>
	                                    <input type="text" name="firstname" placeholder="Firstname" value= "<?php echo $row['first_name']?>" required="">
	                                </div>
	                                <div class="col-md-6 form-group1 form-last">
	                                    <label class="control-label">Last Name</label>
	                                    <input type="text" name="lastname" placeholder="Lastname" value= "<?php echo $row['last_name']?>" required="">
	                                </div>
	                                <div class="clearfix"></div>
                                </div>
                                
                                <div class="vali-form vali-form1">
	                                <div class="col-md-6 form-group1">
										<label class="control-label">Email</label>
										<input type="text" name="email" placeholder="Email" value= "<?php echo $row['email']?>" required="">
	                                </div>

	                                <div class="col-md-6 form-group1">
										<label class="control-label">Mobile Number</label>
										<input type="text" name= "mobile_no" placeholder="Mobile Number" value= "<?php echo $row['mobile_number']?>" required="">
										<p class="hint-block">Numeric values from 0**-*******</p>
	                                </div>
	                                <div class="clearfix"> </div>
                                </div>

                                <div class="clearfix"> </div>
                            
                                <div class="col-md-12 form-group">
                                	<a class="btn btn-warning" href="index.php">Back</a>
									<button class="btn btn-success" type="submit" name="submit" value="submit">Update</button>
									<button type="reset" class="btn btn-primary">Reset</button>
                                </div>
                            <div class="clearfix"> </div>
                        </form>
						</div>
					</div>			
					<div class="clearfix"> </div>	
				</div>
			</div>

			<div class="modal bs-example-modal-sm" tabindex="-1" role="dialog" aria-hidden="true">
				<div class="modal-dialog modal-sm">
					<div class="modal-content">
						<div class="modal-header"><h4>Logout <i class="fa fa-lock"></i></h4></div>
						<div class="modal-body"><i class="fa fa-question-circle"></i> Are you sure you want to log-off?</div>
						<div class="modal-footer"><a href="logout.php" class="btn btn-primary btn-block">Logout</a></div>
					</div>
				</div>
			</div>
				
<!-- script-for sticky-nav -->
<script>
	$(document).ready(function() {
		var navoffeset=$(".header-main").offset().top;
		$(window).scroll(function(){
		var scrollpos=$(window).scrollTop(); 
		if(scrollpos >=navoffeset){
			$(".header-main").addClass("fixed");
		}else{
			$(".header-main").removeClass("fixed");
		}
		});	
	});
</script>
<!-- /script-for sticky-nav -->
<!--inner block start here-->
<div class="inner-block">

</div>
<!--inner block end here-->
<!--copy rights start here-->
<?php include "copyrights.php"; ?>
<!--COPY rights end here-->
</div>
</div>
<!--//content-inner-->
<!--/sidebar-menu-->
<?php include "menu.php"; ?>
<!--js -->
<script src="../js/jquery.nicescroll.js"></script>
<script src="../js/scripts.js"></script>
<!-- Bootstrap Core JavaScript -->
<script src="../js/bootstrap.min.js"></script>
<!-- /Bootstrap Core JavaScript -->	   
<!-- candlestick -->
	<script type="text/javascript" src="js/jquery.jqcandlestick.min.js"></script>
	<link rel="stylesheet" type="text/css" href="css/jqcandlestick.css" />
<!-- //candlestick -->
</body>
</html>