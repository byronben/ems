<div class="sidebar-menu">

    <header class="logo1">
        <a href="#" class="sidebar-icon"> <span class="fa fa-bars"></span> </a> 
    </header>

    <div style="border-top:1px ridge rgba(255, 255, 255, 0.15)"></div>
        <div class="menu">
            <ul id="menu" >
                <li>
                    <a href="index.php"><i class="fa fa-tachometer"></i> <span>Dashboard</span><div class="clearfix"></div></a>
                </li>
                <li id="menu-academico">
                    <a href="profile_update.php"><i class="fa fa-edit"></i><span>Edit Profile</span><div class="clearfix"></div></a>
                </li>
                <li id="menu-academico">
                    <a href="change_password.php"><i class="fa fa-lock"></i><span>Change Password</span><div class="clearfix"></div></a>
                </li>
                <li>
                    <a href="minutes.php"><i class="fa fa-copy"></i> <span>Meeting Minutes</span><div class="clearfix"></div></a>
                </li>
                <li>
                    <a href="user_tasks.php"><i class="fa fa-tasks"></i> <span>Pending Tasks</span><div class="clearfix"></div></a>
                </li>
                <li>
                    <a href="user_tasks_completed.php"><i class="fa fa-check"></i> <span>Completed Tasks</span><div class="clearfix"></div></a>
                </li>
                <li id="menu-academico">
                    <a href="feedback.php"><i class="fa fa-comment"></i><span>Feedback</span><div class="clearfix"></div></a>
                </li>
            </ul>
        </div>
    </div>

    <div class="clearfix"></div>
		
</div>

<script>
    var toggle = true;
                
    $(".sidebar-icon").click(function() {                
        if (toggle)
        {
            $(".page-container").addClass("sidebar-collapsed").removeClass("sidebar-collapsed-back");
            $("#menu span").css({"position":"absolute"});
        }
        else
        {
            $(".page-container").removeClass("sidebar-collapsed").addClass("sidebar-collapsed-back");
            setTimeout(function() {
                $("#menu span").css({"position":"relative"});
            }, 400);
        }
        toggle = !toggle;
    });
</script>