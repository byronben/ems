<?php include "../includes/session.php"; ?>
<!DOCTYPE HTML>
<html>
<head>
	<?php include "header.php"; ?>

	<!-- For table -->
	<link rel="stylesheet" type="text/css" href="../css/table-style.css" />
	<link rel="stylesheet" type="text/css" href="../css/basictable.css" />
	<script type="text/javascript" src="../js/jquery.basictable.min.js"></script>
	<script type="text/javascript">
		$(document).ready(function() {
			$('#table').basictable();
		});
	</script>
	<!-- For table -->
</head> 
<body>
	<div class="page-container">
	<!--/content-inner-->
	<div class="left-content">
		<div class="mother-grid-inner">
			<?php include "header_panel.php"; ?>

		<ol class="breadcrumb">
				<li class="breadcrumb-item"><a href="index.html">Home</a><i class="fa fa-angle-right"></i>Minutes</li>
		</ol>

	<div class="w3-agile-chat">
		<div class="agile-tables">
			<div class="w3l-table-info">
				<h2>Meeting Minutes</h2>
				<table id="table">

				<thead>
					<tr>
					<th>No.</th>
					<th>Title</th>
					<th>Prepared by</th>
					<th colspan="2" align="center">Action</th>
					</tr>
				</thead>

				<tbody>
					<?php
						include "../includes/connect_db.php";
						$query = "SELECT DISTINCT min.meeting_id, min.prepared_by FROM `minutes` min JOIN `attendees` att ON min.meeting_id = att.meeting_id WHERE att.user_id = '$staffid'";
						$result = mysqli_query($con, $query); 
						if(mysqli_num_rows($result) == 0) {
							echo '<tr class="odd gradeX"><td colspan="8">Record not found</td></tr>';                     
						}
						$i=0;
						while ($row = mysqli_fetch_assoc($result)){
							$mid = $row['meeting_id'];
							$m_query = "SELECT * FROM `meeting` WHERE meeting_id = '$mid'";
							$m_result = mysqli_query($con, $m_query);
							$m_row = mysqli_fetch_assoc($m_result);
							$from_date = $m_row['from_date']; 
							$to_date = $m_row['to_date'];
							$new_from_date = date("d/m/Y",strtotime($from_date));
							$new_to_date = date("d/m/Y",strtotime($to_date));
					?>
					<tr>
					<td><?php echo $i+1 ?></td>
					<td><?php echo $m_row['title'] ?></td>
					<?php
						$maker_id = $row['prepared_by'];
						$s_query = "SELECT * FROM `staff` WHERE user_id = '$maker_id'";
						$s_result = mysqli_query($con, $s_query);
					$s_row = mysqli_fetch_assoc($s_result);
					?>
					<td><?php echo $s_row['first_name']." ".$s_row['last_name'] ?></td>
					<td>
						<a href="minute_details.php?id=<?php echo $row['meeting_id'] ?>" class="btn btn-primary">View</a>
					</td>
					</tr>
					<?php $i+=1; } ?>
				</tbody>
				</table>
			</div>
		</div>
				
<?php include "import_js.php"; ?>

</body>
</html>