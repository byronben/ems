<?php 
    session_start();
    $user = $_SESSION["email"];
    $first_name = $_SESSION["first_name"];
    $last_name = $_SESSION["last_name"];
    $role = $_SESSION["role"];
    $staffid = $_SESSION["user_id"];
?>