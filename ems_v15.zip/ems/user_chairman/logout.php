<?php
	session_start(); 
	if (isset($_SESSION["email"])) {   
        session_destroy();
        echo "<script>alert('Logged Out');</script>";
		header("Location: login.php");
	} 
	else {
		echo " No session exists or session is expired. Please log in again";
	}
?>