<?php include "../includes/session.php"; ?>
<!DOCTYPE HTML>
<html>
<head>
	<?php include "header.php"; ?>

	<!-- For table -->
	<link rel="stylesheet" type="text/css" href="../css/table-style.css" />
	<link rel="stylesheet" type="text/css" href="../css/basictable.css" />
	<script type="text/javascript" src="../js/jquery.basictable.min.js"></script>
	<!-- For table -->
</head>

<body>

<div class="page-container">
<!--/content-inner-->
<div class="left-content">
	<div class="mother-grid-inner">
		<?php include "header_panel.php"; ?>

		<ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php">Home</a><i class="fa fa-angle-right"></i>Feedback
            <i class="fa fa-angle-right"></i>Give Feedback</li>
		</ol>
		
		<?php
            include "../includes/connect_db.php";
            $id = (isset($_GET['id']) ? $_GET['id'] : null);

			$description =(isset($_POST['description']) ? $_POST['description'] : null);

            $info_query = "SELECT * FROM meeting WHERE meeting_id = '".$id."'";
            $info_result = mysqli_query($con, $info_query);
            $info_row = mysqli_fetch_assoc($info_result);

			$action =(isset($_POST['submit']) ? $_POST['submit'] : null);
			if($action != null) {		

				$q_insert= "INSERT into feedback (user_id, description, meeting_id)VALUES('$staffid', '$description', '$id')";
				$result=mysqli_query($con, $q_insert);
				if($result) {
                    echo"<script type='text/javascript'>alert('Thank you for your feedback !')</script>";						
				}
				else {
					echo "<font style='color:red'>Unable to send feedback !</font><br><br>";		
				}
			}
		?>
		<div class="w3-agile-chat">
				<div class="charts">
					<div class="col-adjust-10">
						<div class="charts-grids widget">
							<h4 class="title">Meeting Feedback</h4>

                            <form action="give_feedback.php?id=<?php echo $id ?>" method="post">
                                <div class="vali-form vali-form1">
									<div class="col-md-6 form-group1">
									<label class="control-label">Feedback</label>
									<textarea name="description" placeholder="Description of your feedback..." value=""></textarea>
                                	</div>
                                </div>

                                <div class="clearfix"><br/> </div>
								<div class="clearfix"><br> </div>
                            
                                <div class="col-md-12 form-group">
                                    <a href="index.php" class="btn btn-info" name="back">Back</a>
                                    <button class="btn btn-success" type="submit" name="submit" value="submit">Send Feedback</button>
                                </div>
                            <div class="clearfix"> </div>
                        </form>
						</div>
					</div>			
					<div class="clearfix"> </div>	
				</div>
			</div>

<?php include "import_js.php"; ?>

</body>
</html>