<?php include "../includes/session.php"; ?>
<!DOCTYPE HTML>
<html>
<head>
	<?php include "header.php"; ?>

	<!-- For table -->
	<link rel="stylesheet" type="text/css" href="../css/table-style.css" />
	<link rel="stylesheet" type="text/css" href="../css/basictable.css" />
	<script type="text/javascript" src="../js/jquery.basictable.min.js"></script>
	<script type="text/javascript">
		$(document).ready(function() {
			$('#table').basictable();
		});
	</script>
	<!-- For table -->
</head> 
<body>
	<div class="page-container">
	<!--/content-inner-->
	<div class="left-content">
		<div class="mother-grid-inner">
			<?php include "header_panel.php"; ?>

		<ol class="breadcrumb">
				<li class="breadcrumb-item"><a href="index.html">Home</a><i class="fa fa-angle-right"></i>
				Meetings</li>
		</ol>

	<div class="w3-agile-chat">
		<div class="agile-tables">
			<div class="w3l-table-info">
				<h2>Meetings</h2>
				<table id="table">

				<thead>
					<tr>
					<th>No.</th>
<!-- 					<th>Meeting ID</th> -->
					<th>Title</th>
					<th>Venue</th>
					<th>From</th>
					<th>To</th>
					<th>Start Time</th>
					<th>End Time</th>
					<th>Action</th>
					</tr>
				</thead>

				<tbody>
					<?php
						include "../includes/connect_db.php";
						$att_query = "SELECT * FROM `attendees` WHERE user_id = $staffid";
						$att_result = mysqli_query($con, $att_query);
						if(mysqli_num_rows($att_result) == 0) {
							echo '<tr class="odd gradeX"><td colspan="8">Record not found</td></tr>';                     
						}

						$i=0;
						while ($att_row = mysqli_fetch_assoc($att_result)){
							$mid = $att_row['meeting_id'];
							$query = "SELECT * FROM `meeting` where meeting_id = $mid";
							$result = mysqli_query($con, $query);
							$row = mysqli_fetch_assoc($result);
							$from_date = $row['from_date']; 
							$to_date = $row['to_date'];
							$new_from_date = date("d/m/Y",strtotime($from_date));
							$new_to_date = date("d/m/Y",strtotime($to_date));
					
					?>
					<tr>
					<td><?php echo $i+1 ?></td>

					<td><?php echo $row['title'] ?></td>
					<td><?php echo $row['venue'] ?></td>
					<td><?php echo $new_from_date ?></td>
					<td><?php echo $new_to_date ?></td>
					<td><?php echo $row['start_time'] ?></td>
					<td><?php echo $row['end_time'] ?></td>
					<td>
						<a href="meeting_details.php?id=<?php echo $row['meeting_id'] ?>" class="btn btn-primary">View</a>&nbsp
					</td>
					</tr>
					<?php $i+=1; }?>
				</tbody>
				</table>
			</div>
		</div>	
				
<?php include "import_js.php"; ?>

</body>
</html>