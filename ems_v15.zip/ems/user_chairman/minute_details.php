<?php include "../includes/session.php"; ?>
<!DOCTYPE HTML>
<html>
<head>
	<?php include "header.php"; ?>

	<!-- For table -->
	<link rel="stylesheet" type="text/css" href="../css/table-style.css" />
	<link rel="stylesheet" type="text/css" href="../css/basictable.css" />
	<script type="text/javascript" src="../js/jquery.basictable.min.js"></script>
	<!-- For table -->

	<!-- For success modal -->
	<link rel="stylesheet" type="text/css" href="../css/success-modal.css" />
	<!-- For success modal -->

	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/clocklet@0.2.6/css/clocklet.min.css">
	<script src="https://cdn.jsdelivr.net/npm/clocklet@0.2.6"></script>
	<!-- timepicker -->
</head>

<body>

<div class="page-container">
<!--/content-inner-->
<div class="left-content">
	<div class="mother-grid-inner">
		<?php include "header_panel.php"; ?>

		<ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php">Home</a><i class="fa fa-angle-right"></i>Meetings
            <i class="fa fa-angle-right"></i>Details</li>
		</ol>
		
		<?php
            include "../includes/connect_db.php";

            $id = (isset($_GET['id']) ? $_GET['id'] : null);

            $seen_query = "UPDATE meeting SET seen = 1 WHERE meeting_id = '$id' ";
            $seen_query_result = mysqli_query($con, $seen_query);

			$title =(isset($_POST['title']) ? $_POST['title'] : null);
			$venue =(isset($_POST['venue']) ? $_POST['venue'] : null);
			$from_date =(isset($_POST['from_date']) ? $_POST['from_date'] : null);
			$to_date =(isset($_POST['to_date']) ? $_POST['to_date'] : null);
			$start_time =(isset($_POST['start_time']) ? $_POST['start_time'] : null);
			$end_time =(isset($_POST['end_time']) ? $_POST['end_time'] : null);
			$agenda =(isset($_POST['agenda']) ? $_POST['agenda'] : null);
			$status =(isset($_POST['status']) ? $_POST['status'] : null);
			$min_status =(isset($_POST['min_status']) ? $_POST['min_status'] : null);
			// $verified_by =(isset($_POST['verified_by']) ? $_POST['verified_by'] : null);

            $info_query = "SELECT * FROM meeting WHERE meeting_id = '".$id."'";
            $info_result = mysqli_query($con, $info_query);
            $info_row = mysqli_fetch_assoc($info_result);

            $new_from_date = date("d/m/Y",strtotime($info_row['from_date']));
			$new_to_date = date("d/m/Y",strtotime($info_row['to_date']));

			$min_query = "SELECT * FROM minutes WHERE meeting_id = '".$id."'";
			$min_result = mysqli_query($con, $min_query);
			$min_row = mysqli_fetch_assoc($min_result);

			$maker_id = $min_row['prepared_by'];
			$maker_query = "SELECT * FROM staff WHERE user_id = '".$maker_id."'";
			$maker_result = mysqli_query($con, $maker_query);
			$maker_row = mysqli_fetch_assoc($maker_result);
			$maker_fname = $maker_row['first_name'];
			$maker_lname = $maker_row['last_name'];
			$maker_name = $maker_fname." ".$maker_lname;

			$v_id = $min_row['verified_by'];
			$v_query = "SELECT * FROM staff WHERE user_id = '".$v_id."'";
			$v_result = mysqli_query($con, $v_query);
			$v_row = mysqli_fetch_assoc($v_result);
			$v_fname = $v_row['first_name'];
			$v_lname = $v_row['last_name'];
			$v_name = $v_fname." ".$v_lname;

			$q_file = "SELECT fileName FROM documents WHERE meeting_id = '$id' ";
			$r_file = mysqli_query($con, $q_file);
			$info_file = mysqli_fetch_assoc($r_file);
			$fileName = $info_file['fileName'];

			$action =(isset($_POST['submit']) ? $_POST['submit'] : null);
			if($action != null) {
				$q_verify= "UPDATE `minutes` SET status = '$min_status', verified_by = '$staffid' WHERE meeting_id = $id";
				echo $q_verify;
				$result_verify = mysqli_query($con, $q_verify)or die(mysqli_error($con));
				if($result_verify){
					echo "<script>$(document).ready(function(){
							    $('#SucModal').modal('show');
							    $('#button1').click(function(){
							      $('#newModal').modal('hide');
							    });
							  });</script>";
				}
			}
		?>
		<div class="w3-agile-chat">
				<div class="charts">
					<div class="col-adjust-10">
						<div class="charts-grids widget">
							<h4 class="title">Minute Details</h4>

							<!-- Modal HTML -->
							<div id="SucModal" class="modal fade">
								<div class="modal-dialog modal-confirm">
									<div class="modal-content">
										<div class="modal-header">			
											<h4 class="modal-title">Minute Meeting Updated!</h4>	
										</div>
										<div class="modal-body">
											<p class="text-center">Your meeting was updated successfully</p>
										</div>
										<div class="modal-footer">
											<a href="minute_details.php?id=<?php echo $id ?>" class="btn btn-success btn-block">OK</a>
										</div>
									</div>
								</div>
							</div>

                            <form action="minute_details.php?id=<?php echo $id ?>" method="post">
                                <div class="vali-form">
									<div class="col-md-6 form-group1">
										<label class="control-label">Meeting Title</label>
										<input type="text" id="title" name="title" placeholder="Meeting Title" value="<?php echo $info_row['title'] ?>">
									</div>
									<div class="col-md-6 form-group1">
										<label class="control-label">Venue</label>
										<input type="text" id="venue" name="venue" placeholder="Venue" value="<?php echo $info_row['venue'] ?>">
									</div>
                                	<div class="clearfix"></div>
								</div>

								<div class="vali-form vali-form1">
									<div class="col-md-6 form-group1">
										<label class="control-label">From Date</label>
										<input type="text" id="from" name="from_date" value="<?php echo $info_row['from_date']; ?>">
										<input type="hidden" id="new_from" value="<?php echo $new_from_date ?>"/>
									</div>

									<div class="col-md-6 form-group1">
										<label class="control-label">To Date</label>
										<input type="text" id="to" name="to_date" value="<?php echo $info_row['to_date']; ?>">
										<input type="hidden" id="new_to" value="<?php echo $new_to_date ?>"/>
									</div>
                                	<div class="clearfix"> </div>
								</div>

								<div class="vali-form vali-form1">
									<div class="col-md-6 form-group1">
										<label class="control-label">Start Time</label>
										<input data-clocklet="format: h:mm a" id = "start_time" name='start_time' value= "<?php echo $info_row['start_time'] ?>" disabled/>
	                                </div>

	                            	<div class="col-md-6 form-group1">
										<label class="control-label">End Time</label>
										<input data-clocklet="format: h:mm a" id = "end_time" name='end_time' value= "<?php echo $info_row['end_time'] ?>" disabled/>
	                            	</div>

	                            	<div class="clearfix"> </div>
                                </div>

                                <div class="vali-form vali-form1">
									<div class="col-md-6 form-group1">
									<label class="control-label">Agenda</label>
									<textarea id = "agenda" name="agenda" placeholder="Agenda"><?php echo $info_row['agenda'] ?></textarea>
                                	</div>
                                </div>

                                <div class="vali-form vali-form1">
									<div class="col-md-6 form-group1">
									<label class="control-label">Prepared by</label>
									<input id = "prepared_by" name="prepared_by" placeholder="Prepared By" value="<?php echo $maker_name ?>" disabled/><br><br>
									<label class="control-label">Status &nbsp&nbsp</label>
									
									<select id = "min_status" name="min_status" >
										<option value="<?php echo $min_row['status'] ?>"><?php echo $min_row['status'] ?></option>
										<option value="Approved">Approved</option>
										<option value="Rejected">Rejected</option>
									</select>
									<br><br>
									<label class="control-label">Verified by</label>
									<input id = "verified_by" name="verified_by" value="<?php echo $v_name ?>" disabled/>
                                	</div>
                                </div>

								<div class="clearfix"><br/> </div>
								<div class="clearfix"><br> </div>

								<div class="vali-form vali-form1">
									<div class="col-md-12 form-group1">
									<label class="control-label">Other Notes</label>
									<textarea id = "other_notes" name="other_notes" placeholder="Other Notes"><?php echo $min_row['other_notes'] ?></textarea>
                                	</div>
                                </div>

                                <div class="clearfix"><br/> </div>
								<div class="clearfix"><br> </div>
                            
                            	<!--Extension -->

	                        	<h2>Attendees</h2>
								<table id="attendance">

								<thead>
									<tr>
									<th>No.</th>
									<th>Staff ID</th>
									<th>Name</th>
									<th>Role</th>
									<!-- <th>Action</th> -->
									</tr>
								</thead>

								<tbody>
									<?php
										$arr_attend = array();
										$names ="";
										include "../includes/connect_db.php";
										$id = (isset($_GET['id']) ? $_GET['id'] : null);
										$query = "SELECT * FROM `attendees` WHERE meeting_id = $id";
										$result = mysqli_query($con, $query); 
										if(mysqli_num_rows($result) == 0) {
											echo '<tr class="odd gradeX"><td colspan="8">Record not found</td></tr>';                     
										}
										$i=0;
										while ($row = mysqli_fetch_assoc($result)){
									?>
									<tr>
									<td><?php echo $i+1 ?></td>
									<td><?php $staffid=$row['user_id'];
									echo $staffid; ?></td>
									<?php 
										$sub_query = "SELECT * FROM `staff` where user_id = $staffid ";
										$sub_result = mysqli_query($con, $sub_query);
										$sub_row = mysqli_fetch_assoc($sub_result);
									?>
									<td><?php echo $sub_row['first_name']," ", $sub_row['last_name'] ?></td>
									<td><?php echo $sub_row['role']; ?></td>
									</tr>
									<?php 
										$i+=1; 
										array_push($arr_attend, $sub_row['first_name']);
										$names = $sub_row['first_name']." ".$sub_row['last_name'].", "; 
									} ?>
								</tbody>
								</table>

								<br/>
								<h2>Tasks</h2>
								<div>
									<table id="task">
											<tr>
												<th>Task</th>
												<th>Action By</th>
											</tr>
											<?php 
												$t_query = "SELECT * FROM `task` WHERE meeting_id = $id";
												$t_result = mysqli_query($con, $t_query);
												while ($t_row = mysqli_fetch_assoc($t_result)){
													$assignee_id = $t_row['action_by'];
											?>
											<tr>
												
												<td><?php echo $t_row['description'] ?></td>
												<td><?php echo $assignee_id ?></td>
											</tr>
										<?php } ?>
									</table>
								</div>  
								<br/>

								<div style="display:none">
									<table id="prattend">
											<tr>
												<td>Name</td>
												<td>Status</td>
											</tr>
											<?php
												$arr_attend = array();
												$names ="";
												include "../includes/connect_db.php";
												$id = (isset($_GET['id']) ? $_GET['id'] : null);
												$query = "SELECT * FROM `attendees` WHERE meeting_id = $id";
												$result = mysqli_query($con, $query); 
												if(mysqli_num_rows($result) == 0) {
													echo '<tr class="odd gradeX"><td colspan="8">Record not found</td></tr>';                     
												}
												$i=0;
												while ($st_row = mysqli_fetch_assoc($result)){
											?>
											<tr>
											<?php
												$st_id=$st_row['user_id'];
												$sub_query = "SELECT * FROM `staff` where user_id = $st_id ";
												$sub_result = mysqli_query($con, $sub_query);
												$sub_row = mysqli_fetch_assoc($sub_result);
											?>
											<td><?php echo $sub_row['first_name']," ", $sub_row['last_name'] ?></td>
											<td><?php echo $st_row['act_status']; ?></td>
											</tr>
											<?php 
												$i+=1; 
												array_push($arr_attend, $sub_row['first_name']);
												$names = $sub_row['first_name']." ".$sub_row['last_name'].", "; 
											} ?>
									</table>
								</div>

								<div style="display:none">
									<table id="prtask">
											<tr>
												<td>Task</td>
												<td>Action By</td>
											</tr>
											<?php 
												$t_query = "SELECT * FROM `task` WHERE meeting_id = $id";
												$t_result = mysqli_query($con, $t_query);
												while ($t_row = mysqli_fetch_assoc($t_result)){
													$assignee_id = $t_row['action_by'];
													$assign_subquery = "SELECT * FROM `staff` where user_id = $assignee_id ";
													$assign_result = mysqli_query($con, $assign_subquery);
													$assign_row = mysqli_fetch_assoc($assign_result);
													$st_fname = $assign_row['first_name'];
													$st_lname = $assign_row['last_name'];
											?>
											<tr>
												<td><?php echo $t_row['description'] ?></td>
												<td><?php echo $st_fname." ".$st_lname." (".$assignee_id.")" ?></td>
											</tr>
										<?php } ?>
									</table>
								</div>
								
	                        	<!--End Extension -->
                                <div class="col-md-12 form-group">
                                	<input type="hidden" id="names" value="<?php echo $names ?>"/>
                                    <a href="minutes.php" class="btn btn-info" name="back">Back</a>
                                    <button type="submit" name="submit" value="submit" class="btn btn-success">Confirm </button>
                                    <button type="button" class="btn btn-success" onclick="Print()" style="background-color: purple"><span class="glyphicon glyphicon-print" style="color:white"></span> Print </button>
                                </div>
                            <div class="clearfix"> </div>
                        </form>
						</div>
					</div>			
					<div class="clearfix"> </div>	
				</div>
			</div>
				
<!--script for task assigning-->
<script> 

$(document).ready(function(){
	var mid = "<?php echo $id ?>"; 
    function fetch_data(mid)  
    {
        $.ajax({  
            url:"task_actions/select.php",  
            method:"POST",
            data:{mid:mid},  
            dataType:"text",
            success:function(data){  
				$('#live_data').html(data);  
            }  
        });  
    }  
    fetch_data(mid);  
    $(document).on('click', '#btn_add', function(){

        var description = $('#description').text();  
        var action_by = $('#action_by').text();  
        if(description == '')  
        {  
            alert("Enter Task");  
            return false;  
        }  
        if(action_by == '')  
        {  
            alert("Assign Task Please");  
            return false;  
        }  
        $.ajax({  
            url:"task_actions/insert.php",  
            method:"POST",  
            data:{description:description, action_by:action_by, mid:mid},  
            dataType:"text",  
            success:function(data)  
            {  
            	alert(data);
            	fetch_data(mid);
            }  
        })  
    });  
    
	function edit_data(id, text, column_name)  
    {  
        $.ajax({  
            url:"task_actions/edit.php",  
            method:"POST",  
            data:{id:id, text:text, column_name:column_name},  
            dataType:"text",  
            success:function(data){  
                //alert(data);
				$('#result').html("<div class='alert alert-success'>"+data+"</div>");
				fetch_data(mid);
            }  
        });  
    }  
    $(document).on('blur', '.description', function(){  
        var id = $(this).data("id1");  
        var description = $(this).text();  
        edit_data(id, description, "description");  
    });  
    $(document).on('blur', '.action_by', function(){  
        var id = $(this).data("id2");  
        var action_by = $(this).text();  
        edit_data(id,action_by, "action_by");
    });  
    $(document).on('click', '.btn_delete', function(){  
        var id=$(this).data("id3");  
        if(confirm("Are you sure you want to delete this?"))  
        {  
            $.ajax({  
                url:"task_actions/delete.php",  
                method:"POST",  
                data:{id:id},  
                dataType:"text",  
                success:function(data){  
                    alert(data);  
                    fetch_data(mid);  
                }  
            });  
        }  
    });  
});

function Print() {
	var prtAttend = document.getElementById("prattend");
	var prtTask = document.getElementById("prtask");
	var title = document.getElementById("title").value;
	var venue = document.getElementById("venue").value;
	var from = document.getElementById("new_from").value;
	var to = document.getElementById("new_to").value;
	var start_time = document.getElementById("start_time").value;
	var end_time = document.getElementById("end_time").value;
	var agenda = document.getElementById("agenda").value;
	var other_notes = document.getElementById("other_notes").value;
	var names = document.getElementById("names").value;
	var min_status = document.getElementById("min_status").value;
	var verified_by = document.getElementById("verified_by").value;

	var WinPrint = window.open('', '', 'letf=0,top=0,width=900,height=800,toolbar=0,scrollbars=1,status=0');
	WinPrint.document.write('<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">');
	WinPrint.document.write('<html xmlns="http://www.w3.org/1999/xhtml">');
	WinPrint.document.write('<head><h1 align="center">Meeting Minute for ',title,'</h1></head>');
	WinPrint.document.write('<body">');
	WinPrint.document.write('<table align="center" style="width:700px">');
	WinPrint.document.write('<tr><td style="background-color:#F6F6F6" colspan="1">Title: </td>');
	WinPrint.document.write('<td colspan="3">',title,'</td></tr>');
	
	WinPrint.document.write('<tr><td style="background-color:#F6F6F6">Start Time: </td>');
	WinPrint.document.write('<td>',start_time,'</td>');
	WinPrint.document.write('<td style="background-color:#F6F6F6">End Time: </td>');
	WinPrint.document.write('<td>',end_time,'</td></tr>');

	WinPrint.document.write('<tr><td style="background-color:#F6F6F6">Start Date Of Meeting: </td>');
	WinPrint.document.write('<td>',from,'</td>');
	WinPrint.document.write('<td style="background-color:#F6F6F6">End Date Of Meeting: </td>');
	WinPrint.document.write('<td>',to,'</td></tr>');

	WinPrint.document.write('<tr><td style="background-color:#F6F6F6">Minutes Prepared by: </td>');
	WinPrint.document.write('<td>',"<?php echo $maker_name ?>",'</td>');
	WinPrint.document.write('<td style="background-color:#F6F6F6">Location: </td>');
	WinPrint.document.write('<td>',venue,'</td></tr>');
	WinPrint.document.write('<tr><td style="background-color:#F6F6F6">Agenda: </td>');
	WinPrint.document.write('<td colspan="3">',agenda,'</td></tr>');

	WinPrint.document.write('<tr><td colspan="4" style="background-color:#F6F6F6">Attendees: </td>');
	WinPrint.document.write('<tr><td colspan="4">',prtAttend.innerHTML,'</td></tr>');
	WinPrint.document.write('<tr><td colspan="4" style="background-color:#F6F6F6;text_align:center">Tasks Assigned </td></tr>');
	WinPrint.document.write('<tr><td colspan="4">',prtTask.innerHTML,'</td></tr>');
	WinPrint.document.write('<tr><td style="background-color:#F6F6F6">Other Notes: </td>');
	WinPrint.document.write('<td colspan="3">',other_notes,'</td></tr>');
	WinPrint.document.write('<tr><td style="background-color:#F6F6F6">Status: </td>');
	WinPrint.document.write('<td colspan="1">',min_status,'</td></tr>');
	WinPrint.document.write('<tr><td style="background-color:#F6F6F6">Verified by: </td>');
	WinPrint.document.write('<td colspan="2">',verified_by,'</td></tr>');
	WinPrint.document.write('</table>');
	WinPrint.document.write('</body></html>');
	WinPrint.document.write('<style>table, th, td {border: 0.5px solid black;}</style>')
	WinPrint.document.close();
	WinPrint.focus();
	WinPrint.print();
	WinPrint.close();
}

</script>
<!--script for task assigning-->

<?php include "import_js.php"; ?>

</body>
</html>