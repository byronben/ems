<?php include "../includes/session.php"; ?>
<!DOCTYPE HTML>
<html>
<head>
	<?php include "header.php"; ?>

	<!-- For table -->
	<link rel="stylesheet" type="text/css" href="../css/table-style.css" />
	<link rel="stylesheet" type="text/css" href="../css/basictable.css" />
	<script type="text/javascript" src="../js/jquery.basictable.min.js"></script>
	<!-- For table -->

	<!-- For autocomplete -->
	<script type="text/javascript" src="../js/jquery-1.4.2.min.js"></script>
	<script type="text/javascript" src="../js/jquery.autocomplete.js"></script>
	<!-- For autocomplete -->

	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/clocklet@0.2.6/css/clocklet.min.css">
	<script src="https://cdn.jsdelivr.net/npm/clocklet@0.2.6"></script>
	<!-- timepicker -->

	<!---datepicker-->
	<?php //include "datepicker_css_js.php"; ?>
	<?php //include "new_datepicker.php"; ?>
</head>

<body>

<div class="page-container">
<!--/content-inner-->
<div class="left-content">
	<div class="mother-grid-inner">
		<?php include "header_panel.php"; ?>

		<ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php">Home</a><i class="fa fa-angle-right"></i>Meetings
            <i class="fa fa-angle-right"></i>Details</li>
		</ol>
		
		<?php
            include "../includes/connect_db.php";
            $id = (isset($_GET['id']) ? $_GET['id'] : null);
            $task_id = (isset($_GET['task_id']) ? $_GET['task_id'] : null);
            $task_status_check = (isset($_GET['is_task_p']) ? $_GET['is_task_p'] : null);
			$title =(isset($_POST['title']) ? $_POST['title'] : null);
			$venue =(isset($_POST['venue']) ? $_POST['venue'] : null);
			$from_date =(isset($_POST['from_date']) ? $_POST['from_date'] : null);
			$to_date =(isset($_POST['to_date']) ? $_POST['to_date'] : null);
			$start_time =(isset($_POST['start_time']) ? $_POST['start_time'] : null);
			$end_time =(isset($_POST['end_time']) ? $_POST['end_time'] : null);
			$agenda =(isset($_POST['agenda']) ? $_POST['agenda'] : null);

            $info_query = "SELECT * FROM meeting WHERE meeting_id = '".$id."'";
            $info_result = mysqli_query($con, $info_query);
            $info_row = mysqli_fetch_assoc($info_result);

            $att_query = "SELECT * FROM attendees WHERE meeting_id = '".$id."' AND user_id='".$staffid."'";
            $att_result = mysqli_query($con, $att_query);
            $att_row = mysqli_fetch_assoc($att_result);
            $pre_status =(isset($_POST['pre_status']) ? $_POST['pre_status'] : null);
			
			$q_file = "SELECT fileName FROM documents WHERE meeting_id = '$id' ";
			$r_file = mysqli_query($con, $q_file);
			$info_file = mysqli_fetch_assoc($r_file);
			$fileName = $info_file['fileName'];

			$action =(isset($_POST['submit']) ? $_POST['submit'] : null);
			if($action != null) {		

				$q_update= "UPDATE attendees SET pre_status = '$pre_status' WHERE meeting_id = '$id' AND user_id = '$staffid'";
				$result=mysqli_query($con, $q_update);
				if($result) {
                    echo"<script type='text/javascript'>alert('Successfully updated meeting ".$id."!')</script>";
                    // header("Refresh:0");							
				}
				else {
					echo "<font style='color:red'>Unable to update meeting !</font><br><br>";		
				}
			}
		?>
		<div class="w3-agile-chat">
				<div class="charts">
					<div class="col-adjust-10">
						<div class="charts-grids widget">
							<h4 class="title">Meeting Details</h4>

                            <form action="meeting_details.php?id=<?php echo $id ?>" method="post">
                                <div class="vali-form">
									<div class="col-md-6 form-group1">
										<label class="control-label">Meeting Title</label>
										<input type="text" name="title" placeholder="Meeting Title" value="<?php echo $info_row['title'] ?>" disabled>
									</div>
									<div class="col-md-6 form-group1">
										<label class="control-label">Venue</label>
										<input type="text" name="venue" placeholder="Venue" value="<?php echo $info_row['venue'] ?>" disabled>
									</div>
                                	<div class="clearfix"></div>
								</div>

								<div class="vali-form vali-form1">
									<div class="col-md-6 form-group1">
										<label class="control-label">From Date</label>
										<input type="text" id="from" name="from_date" value="<?php echo $info_row['from_date']; ?>" disabled>
									</div>

									<div class="col-md-6 form-group1">
										<label class="control-label">To Date</label>
										<input type="text" id="to" name="to_date" value="<?php echo $info_row['to_date']; ?>" disabled>
									</div>
                                	<div class="clearfix"> </div>
								</div>

								<div class="vali-form vali-form1">
									<div class="col-md-6 form-group1">
										<label class="control-label">Start Time</label>
										<input data-clocklet="format: h:mm a" name='start_time' value= "<?php echo $info_row['start_time'] ?>" disabled/>
	                                </div>

	                            	<div class="col-md-6 form-group1">
										<label class="control-label">End Time</label>
										<input data-clocklet="format: h:mm a" name='end_time' value= "<?php echo $info_row['end_time'] ?>" disabled/>
	                            	</div>

	                            	<div class="clearfix"> </div>
                                </div>

                                <div class="vali-form vali-form1">
									<div class="col-md-6 form-group1">
									<label class="control-label">Agenda</label>
									<textarea name="agenda" placeholder="Agenda" disabled><?php echo $info_row['agenda'] ?></textarea>
                                	</div>

                                    <div class="col-md-6 form-group1">
									<label class="control-label">File for Reference</label>
									<div class="clearfix"><br/> </div>
									<?php 
									if($fileName!=null){
										echo "<a target='_blank' href='../user_secretary/documents/$fileName'><span class='glyphicon glyphicon-eye-open'></span>&nbspView Uploaded File</a>";
									 }
									 else{
										 ?><div>No files attached</div><?php
									 }
									?>
									
                                	</div>
                                </div>

                                <div class="clearfix"><br/> </div>
								<div class="clearfix"><br> </div>

								<?php 
								$completed = 0;
								if($info_row['status'] == "Upcoming"){ ?>
									<div class="col-md-12 form-group">
									<label class="control-label">Attendance : </label>
									<select name="pre_status">
										<option value="<?php echo $att_row['pre_status'] ?>"><?php echo $att_row['pre_status'] ?></option>
										<option value="Attending">Attending</option>
										<option value="Not Attending">Not Attending</option>
										<option value="Representative Attending">Representative Attending</option>
									</select>
                            	</div>
								<?php }else{$completed=1;} ?>							

                                <div class="clearfix"><br/> </div>
								<div class="clearfix"><br> </div>
                            
                                <div class="col-md-12 form-group">
                                	<?php if($task_status_check == 1){ ?>
                                    	<a href="user_tasks.php" class="btn btn-info" name="back">Back</a>
                                    <?php } ?>
                                    <?php if($task_status_check == 2){ ?>
                                    	<a href="user_tasks_completed.php" class="btn btn-info" name="back">Back</a>
                                	<?php } if($task_status_check == 0){?>
                                		<a href="index.php" class="btn btn-info" name="back">Back</a>
                                	<?php } ?>
                                    <?php if($completed != 1){ ?>
                                    	<button class="btn btn-warning" type="submit" name="submit" value="submit">Confirm</button>
                                	<?php } ?>
                                </div>
                            <div class="clearfix"> </div>
                        </form>
						</div>
					</div>			
					<div class="clearfix"> </div>	
				</div>
			</div>

<?php include "import_js.php"; ?>

</body>
</html>