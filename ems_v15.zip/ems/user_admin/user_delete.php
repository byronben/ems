
<?php
    include "../includes/connect_db.php";
    $id =(isset($_GET['user_id']) ? $_GET['user_id'] : null);
    if($id==null)
        $id =(isset($_POST['user_id']) ? $_POST['user_id'] : null);

    $query= "delete from `staff` where user_id =$id";
    $result=mysqli_query($con, $query);
    // echo $query;

    header("Location: index.php", true, 301);
    exit();
?>
