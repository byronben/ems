<!DOCTYPE html>
<html>
<head>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <?php include "../includes/header.php"; ?>
</head>

<?php
    include "../includes/connect_db.php";
    $username =(isset($_POST['username']) ? $_POST['username'] : null);
    $password =(isset($_POST['password']) ? $_POST['password'] : null);

    $action =(isset($_POST['submit']) ? $_POST['submit'] : null);
    if($action!=null) {
																		
        if($username==null || $password==null) {
            echo "<font style='color:red'>Please insert all text fields!</font><br><br>";
		}

        else {
            $query= "SELECT * FROM admin WHERE username='$username' AND password='$password'";
            $result=mysqli_query($con, $query);
            $row = mysqli_fetch_assoc($result);

            if($row['admin_id'] != null) {
				session_start();
                $_SESSION['username'] = $username;
                echo"<script type='text/javascript'>alert('Successfully logged in')</script>";													
                header('Location: index.php');				
            }
            else {
                echo "<font style='color:red'>Incorrect Admin username and/or password</font><br><br>";		
            }
        }
    }
?>

<body>
<div class="container">
	<div class="d-flex justify-content-center h-100">
		<div class="card">
			<div class="card-header">
				<h3>Sign In as Admin</h3>
				<!-- <div class="d-flex justify-content-end social_icon">
					<span><i class="fab fa-facebook-square"></i></span>
					<span><i class="fab fa-google-plus-square"></i></span>
					<span><i class="fab fa-twitter-square"></i></span>
				</div> -->
			</div>
			<div class="card-body">
				<form action="login.php" method="post">

					<div class="input-group form-group">
						<div class="input-group-prepend">
							<span class="input-group-text"><i class="fas fa-user"></i></span>
						</div>
						<input type="text" name="username" class="form-control" placeholder="username">
					</div>

					<div class="input-group form-group">
						<div class="input-group-prepend">
							<span class="input-group-text"><i class="fas fa-key"></i></span>
						</div>
						<input type="password" name="password" class="form-control" placeholder="password">
					</div>

					<!-- <div class="row align-items-center remember">
						<input type="checkbox">Remember Me
					</div> -->

					<div class="form-group">
						<input name="submit" type="submit" value="Login" class="btn float-right login_btn">
					</div>

				</form>
			</div>
			<div class="card-footer">
                <a class="btn login_btn" href="../index.php">Back</a>
				<!-- <div class="d-flex justify-content-center links">
					Don't have an account?<a href="#">Sign Up</a>
				</div> -->
				<!-- <div class="d-flex justify-content-center">
					<a href="#">Forgot your password?</a>
				</div> -->
			</div>
		</div>
	</div>
</div>
</body>
</html>

<?php include "../includes/login_style.php"; ?>