<?php
	include "../includes/connect_db.php";
	$id = (isset($_GET['id']) ? $_GET['id'] : null);
	$query = "SELECT * FROM `staff` WHERE user_id = '$id'";
	$result = mysqli_query($con, $query);
	$row = mysqli_fetch_assoc($result);
	$recipients = $row['email'];

	$content = 
	"Dear Staff,

	An account has been created for you to login to the Electronic Minutes System. Your credentials are as below:

	Username: ".$row['email']."
	Password: ".$row['password']."

	Kindly login to the EMS system and change your password.

	Best Regards,
	EMS Admin";

	$retval = mail($recipients,"Meeting",$content,"From: ronbenji97@gmail.com") or die("Not success");

	if ($retval == true)
	{
	    echo "<script type='text/javascript'>alert('Email sent successfully')</script>";
	    header("Location: create_user.php");
	}
	else if($retval == false)
	{
	   print_r(error_get_last());
	}
?>