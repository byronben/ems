<?php
	define('EMAIL', 'ronbenji97@gmail.com');
	define('PASS', 'adenosine27@');
?>