<!-- script-for sticky-nav -->
<script>
	$(document).ready(function() {
		var navoffeset=$(".header-main").offset().top;
		$(window).scroll(function(){
		var scrollpos=$(window).scrollTop(); 
		if(scrollpos >=navoffeset){
			$(".header-main").addClass("fixed");
		}else{
			$(".header-main").removeClass("fixed");
		}
		});

		function edit_data(id, text, column_name)  
	    {  
	        $.ajax({  
	            url:"edit.php",  
	            method:"POST",  
	            data:{id:id, text:text, column_name:column_name},  
	            dataType:"text",  
	            success:function(data){  
	                //alert(data);
					$('#result').html("<div class='alert alert-success'>"+data+"</div>");
	            }  
	        });  
	    } 
	});
</script>
<!-- /script-for sticky-nav -->
<!--inner block start here-->
<div class="inner-block">
	</div>
	<!--inner block end here-->
	<!--copyrights start here-->
	<?php include "copyrights.php"; ?>
	<!--copyrights start here-->
	</div>
</div>
<!--//content-inner-->
<!--/sidebar-menu-->
<?php include "menu.php"; ?>
<!--/sidebar-menu-->

<!--js -->
<script src="../js/jquery.nicescroll.js"></script>
<script src="../js/scripts.js"></script>
<!-- Bootstrap Core JavaScript -->
<script src="../js/bootstrap.min.js"></script>
<!-- /Bootstrap Core JavaScript -->	   
<!-- candlestick -->
<script type="text/javascript" src="js/jquery.jqcandlestick.min.js"></script>
<link rel="stylesheet" type="text/css" href="css/jqcandlestick.css" />
<!-- //candlestick -->