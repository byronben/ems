<?php

$retval = mail("mbyronbenjamin@gmail.com","Subject","Email message","From: ronbenji97@gmail.com") or die("Not success");

if ($retval == true)
{
    echo "Message accepted";
}
else if($retval == false)
{
   print_r(error_get_last());
}
?>