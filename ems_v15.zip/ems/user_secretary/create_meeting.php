<?php include "../includes/session.php"; ?>

<!DOCTYPE HTML>
<html>
<head>
	<?php include "header.php"; ?>

	<!-- For table -->
	<link rel="stylesheet" type="text/css" href="../css/table-style.css" />
	<link rel="stylesheet" type="text/css" href="../css/basictable.css" />
	<script type="text/javascript" src="../js/jquery.basictable.min.js"></script>
	<!-- For table -->

	<!-- For success modal -->
	<link rel="stylesheet" type="text/css" href="../css/success-modal.css" />
	<!-- For success modal -->

	<!-- timepicker -->
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/clocklet@0.2.6/css/clocklet.min.css">
	<script src="https://cdn.jsdelivr.net/npm/clocklet@0.2.6"></script>
	<!-- timepicker -->

	<!---datepicker-->
	<?php include "new_datepicker.php"; ?>
	<!--datepicker-->
</head>

<body>

<div class="page-container">
<!--/content-inner-->
<div class="left-content">
	<div class="mother-grid-inner">
		<?php include "header_panel.php"; ?>

		<ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php">Home</a><i class="fa fa-angle-right"></i>Create New Meeting</li>
		</ol>
		
		<?php
			include "../includes/connect_db.php";
			$title =(isset($_POST['title']) ? $_POST['title'] : null);
			$venue =(isset($_POST['venue']) ? $_POST['venue'] : null);
			$from_date =(isset($_POST['from']) ? $_POST['from'] : null);
			$to_date =(isset($_POST['to']) ? $_POST['to'] : null);
			$start_time =(isset($_POST['start_time']) ? $_POST['start_time'] : null);
			$end_time =(isset($_POST['end_time']) ? $_POST['end_time'] : null);
			$agenda =(isset($_POST['agenda']) ? $_POST['agenda'] : null);
			$status = "Upcoming";
			$seen = 0;

			$action =(isset($_POST['submit']) ? $_POST['submit'] : null);
			if($action != null) {																	
				$q_insert= "INSERT INTO meeting (title, venue, from_date, to_date, start_time, end_time, agenda, status, seen)VALUES('$title','$venue', '$from_date', '$to_date', '$start_time', '$end_time', '$agenda', '$status', '$seen')";
				$result=mysqli_query($con, $q_insert);

				$q_last_row = "select meeting_id from meeting where meeting_id=(SELECT LAST_INSERT_ID());";
				$result = mysqli_query($con, $q_last_row);
				$row = mysqli_fetch_assoc($result);
				$last_row_id = $row['meeting_id'];
				
				$file1 =(isset($_FILES['fileToUpload']['name']) ? $_FILES['fileToUpload']['name'] : null);

				$target_dir = "documents/";
				$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
				$uploadOk = 1;
				$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

				if(isset($_POST["submit"])) {
					if($file1!=null){
						$check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
						if($check !== false) {
							echo "File is an image - " . $check["mime"] . ".";
							$uploadOk = 1;
						} else {
							echo "File is not an image.";
							$uploadOk = 1;
						}
					}
					else{
						// echo "No file was uploaded. Please try again";
					}	
				}

				if ($uploadOk == 0) {
					echo "Sorry, unable to upload file";

				} else {
					if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
						echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
						$q_upload="insert into documents values(NULL,'$last_row_id','$file1')";
						$upload_result=mysqli_query($con, $q_upload);
						if($upload_result){
							// echo "<font style='color:green'>Successfully uploaded document</font><br>";
						}

					} else {
						// echo "Sorry, there was an error uploading your file.";
					}
				}

				if($result) {
					echo "<script>$(document).ready(function(){
							    $('#SucModal').modal('show');
							    $('#button1').click(function(){
							      $('#newModal').modal('hide');
							    });
							  });</script>";
				}
				else {
					echo "<font style='color:red'>Unable to add new meeting !</font><br><br>";		
				}
			}
		?>
		<div class="w3-agile-chat">
				<div class="charts">
					<div class="col-adjust-10">
						<div class="charts-grids widget">

							<!-- Modal HTML -->
							<div id="SucModal" class="modal fade">
								<div class="modal-dialog modal-confirm">
									<div class="modal-content">
										<div class="modal-header">			
											<h4 class="modal-title">Meeting Created!</h4>	
										</div>
										<div class="modal-body">
											<p class="text-center">Your meeting was created successfully. Please proceed to add attendants for the meeting.</p>
										</div>
										<div class="modal-footer">
											<a href="add_attendee.php?id=<?php echo $last_row_id ?>" class="btn btn-success btn-block">OK</a>
										</div>
									</div>
								</div>
							</div>

							<h4 class="title">Create New Meeting</h4>

                            <form action="create_meeting.php" method="post" enctype="multipart/form-data">
                                <div class="vali-form">
									<div class="col-md-6 form-group1">
										<label class="control-label">Meeting Title</label>
										<input type="text" name="title" placeholder="Meeting Title" required="">
									</div>
									<div class="col-md-6 form-group1">
										<label class="control-label">Venue</label>
										<input type="text" name="venue" placeholder="Venue" required="">
									</div>
                                	<div class="clearfix"></div>
								</div>

								<div class="vali-form vali-form1">
									<div class="col-md-6 form-group1">
									<label class="control-label">Start Date</label>
									<input type="text" id="from" name="from" required>
									</div>

									<div class="col-md-6 form-group1">
									<label class="control-label">End Date</label>
									<input type="text" id="to" name="to" required>
									</div>

									<div class="clearfix"></div>
									
                                </div>

								<div class="vali-form vali-form1">
									<div class="col-md-6 form-group1">
									<label class="control-label">Start Time</label>
									<input data-clocklet="format: h:mm a" name="start_time" value="8:00 am" required>
									</div>

									<div class="col-md-6 form-group1">
									<label class="control-label">End Time</label>
									<input data-clocklet="format: h:mm a" name="end_time" value="5:00 pm" required>
									</div>

									<div class="clearfix"></div>

                                </div>

                                <div class="vali-form vali-form1">
									<div class="col-md-6 form-group1">
									<label class="control-label">Agenda</label>
									<textarea name="agenda" placeholder="Agenda" required=""></textarea>
									</div>
									
									<div class="col-md-6 form-group1">
									<label class="control-label">File for Reference</label>
                                    <div class="clearfix"><br/> </div>
									<input type="file" name="fileToUpload" id="fileToUpload">
                                	</div>
                                </div>
                                
                                <div class="clearfix"><br/> </div>
								<div class="clearfix"><br> </div>
                            	
                                <div class="col-md-12 form-group">
                                	

									
									<?php if($action != null) {
										?>
										<a class="btn btn-success" href="add_attendee.php?id=<?php echo $last_row_id ?>">Add Attendants</a>
										<?php }
										else { ?>
											<button type="reset" class="btn btn-primary">Reset</button>
											<button class="btn btn-success" type="submit" name="submit" value="submit">Next</button>
										<?php }?>
                                </div>
                            <div class="clearfix"> </div>
                        </form>
						</div>
					</div>			
					<div class="clearfix"> </div>	
				</div>
			</div>

<?php include "import_js.php" ?>
</body>
</html>