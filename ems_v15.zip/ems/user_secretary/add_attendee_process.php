<?php
	include "../includes/connect_db.php";
	$id = (isset($_GET['id']) ? $_GET['id'] : null);
	$mid = (isset($_GET['mid']) ? $_GET['mid'] : null);
	$info_query = "SELECT * FROM staff WHERE user_id = '".$id."'";
	$info_result = mysqli_query($con, $info_query);
	$info_row = mysqli_fetch_assoc($info_result);

	$insert_query= "INSERT INTO attendees(user_id, meeting_id, pre_status, act_status)VALUES($id, $mid, 'Awaiting confirmation', 'Unknown')";
	$insert_result = mysqli_query($con, $insert_query);

	if($insert_result){
		echo "<script>alert('Successfully inserted !');</script>";
		header("Location: add_attendee.php?id=$mid");
	}
	else{
		echo "Failed insert";
	}
?>