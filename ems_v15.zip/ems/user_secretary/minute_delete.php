<?php  
	$connect = mysqli_connect("localhost", "root", "", "ems");
	$sql = "DELETE FROM minutes WHERE minute_id = '".$_GET["id"]."'";  
	if(mysqli_query($connect, $sql))  
	{  
		echo 'Meeting Minute has been Deleted';
		header("Location:minutes.php");  
	}  
 ?>