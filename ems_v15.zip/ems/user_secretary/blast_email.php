<?php
	include "../includes/connect_db.php";
	$id = (isset($_GET['id']) ? $_GET['id'] : null);
	$query = "SELECT * FROM `attendees` WHERE meeting_id = $id";
	$m_query = "SELECT * from `meeting` WHERE meeting_id = $id";
	$m_result = mysqli_query($con, $m_query);
	$result = mysqli_query($con, $query);
	$m_row = mysqli_fetch_assoc($m_result);
	$recipients = " ";

	$newFromDate = date("d/m/Y", strtotime($m_row['from_date']));
	$newToDate = date("d/m/Y", strtotime($m_row['to_date']));

	$content = 
	"Dear Staff,

	You are invited to attend a meeting. Meeting details are as below:

	Title: ".$m_row['title']."
	Venue: ".$m_row['venue']."
	Date: ".$newFromDate." - ".$newToDate."
	Time: ".$m_row['start_time']." - ".$m_row['end_time']."
	Agenda: ".$m_row['agenda']."

	Kindly login to the EMS system and confirm your attendance.

	Best Regards,
	Secretary";

	while ($row = mysqli_fetch_assoc($result)){
		$staffid = $row['user_id'];
		$sub_query = "SELECT * FROM `staff` where user_id = $staffid ";
		$sub_result = mysqli_query($con, $sub_query);
		$sub_row = mysqli_fetch_assoc($sub_result);
		$recipients .= $sub_row['email'].",";
	}
	$retval = mail($recipients, "Meeting", $content, "From: ronbenji97@gmail.com") or die("Not success");

	if ($retval == true)
	{
	    echo "<script type='text/javascript'>alert('Email sent successfully')</script>";
	    header("Location: index.php");
	}
	else if($retval == false)
	{
	   print_r(error_get_last());
	}
?>