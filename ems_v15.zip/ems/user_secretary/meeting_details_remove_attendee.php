<?php
    include "../includes/connect_db.php";
    $id = (isset($_GET['id']) ? $_GET['id'] : null);
    $mid = (isset($_GET['mid']) ? $_GET['mid'] : null);
    $query = "DELETE FROM `attendees` WHERE attendee_id = '".$id."'";
    $result = mysqli_query($con, $query);
    if($result){
        echo "<script>alert('Data deleted successfully !');</script>";
        header("Location:meeting_details.php?id=$mid");
    }
?>