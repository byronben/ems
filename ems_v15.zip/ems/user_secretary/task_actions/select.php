<?php  
 $connect = mysqli_connect("localhost", "root", "", "ems"); 
 $output = '';
 $mid = $_POST["mid"];  
 $sql = "SELECT * FROM task WHERE meeting_id =  '".$mid."' ORDER BY task_id DESC";  
 $result = mysqli_query($connect, $sql);
 
 $output .= '
      
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script> 
      <div class="table-responsive">  
           <table class="table table-bordered">  
                <tr>  
                     <th width="10%" style="color: white; font-weight:bold">Task ID</th>  
                     <th width="40%" style="color: white; font-weight:bold">Task</th>
                     <th colspan="2" width="40%" style="color: white; font-weight:bold">Assigned To</th> 
                     <th width="10%" style="color: white; font-weight:bold">Delete / Add</th>  
                </tr>';  
 $rows = mysqli_num_rows($result);
 if($rows > 0)  
 {  
	  if($rows > 10)
	  {
		  $delete_records = $rows - 10;
		  $delete_sql = "DELETE FROM task LIMIT $delete_records";
		  mysqli_query($connect, $delete_sql);
	  }
      while($row = mysqli_fetch_array($result)) 
      {
        $search_staff = "SELECT first_name, last_name from staff where user_id = ".$row["action_by"]."";
        $search_result = mysqli_query($connect, $search_staff);
        $staff_row = mysqli_fetch_array($search_result);
           $output .= '  
                <tr>  
                     <td>'.$row["task_id"].'</td>  
                     <td class="description" data-id1="'.$row["task_id"].'" contenteditable>'.$row["description"].'</td>  
                     <td class="action_by" data-id2="'.$row["task_id"].'" contenteditable>'.$row["action_by"].'</td> 
                    <td class="full_name" data-id4="'.$row["task_id"].'">'.$staff_row["first_name"]." ".$staff_row["last_name"].'</td> 
                     <td><button type="button" name="delete_btn" data-id3="'.$row["task_id"].'" class="btn btn-danger btn_delete"><i class= "fa fa-trash" style="color:white;"></i></button></td> 
                </tr>
           ';  
      }  
      $output .= '  
           <tr>  
                <td></td>  
                <td id="description" contenteditable></td>  
                <td id="action_by" contenteditable></td>  
                <td id="full_name"></td>
                <td><button type="button" name="btn_add" id="btn_add" class="btn btn-success">+</button></td>  
           </tr>  
      ';  
 }  
 else  
 {  
      $output .= '
				<tr>  
					<td></td>  
					<td id="description" contenteditable></td>  
					<td id="action_by" contenteditable></td>
          <td id="full_name"></td>
					<td><button type="button" name="btn_add" id="btn_add" class="btn btn-xs btn-success">+</button></td>  
			   </tr>';  
 }  
 $output .= '</table>  
      </div>';  
 echo $output;  
 ?>