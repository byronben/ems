<?php  
	$connect = mysqli_connect("localhost", "root", "", "ems");
	$sql = "DELETE FROM task WHERE task_id = '".$_POST["id"]."'";  
	if(mysqli_query($connect, $sql))  
	{  
		echo 'Task has been Deleted';  
	}  
 ?>