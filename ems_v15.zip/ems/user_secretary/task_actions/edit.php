<?php  
	$connect = mysqli_connect("localhost", "root", "", "ems");
	$id = $_POST["id"];  
	$text = $_POST["text"];  
	$column_name = $_POST["column_name"];  
	$sql = "UPDATE task SET ".$column_name."='".$text."' WHERE task_id='".$id."'";  
	if(mysqli_query($connect, $sql))
	{  
		echo 'Task Updated';  
	}  
 ?>