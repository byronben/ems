<?php
	$connect = mysqli_connect("localhost", "root", "", "ems");
	$staffid=$_POST["action_by"];

	$search_sql = "SELECT * FROM staff where user_id = ".$staffid."";
	$search_result=mysqli_query($connect, $search_sql);
	$row = mysqli_fetch_assoc($search_result);

	if($row['user_id']){
		$staffid = $row['user_id'];
		$sql = "INSERT INTO task(meeting_id, description, action_by, status) VALUES('".$_POST["mid"]."', '".$_POST["description"]."', '".$_POST["action_by"]."', 'Pending')";

		if($insert = mysqli_query($connect, $sql))  
			echo 'You have added a new task';
	}
	else{
		echo 'Staff could not be found. Please re-enter staff ID.';
	}
?>