<!DOCTYPE html>
<html>
<head>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <?php include "../includes/header.php"; ?>
</head>

<?php
    include "../includes/connect_db.php";
    $email =(isset($_POST['email']) ? $_POST['email'] : null);
    $password =(isset($_POST['password']) ? $_POST['password'] : null);

    $action =(isset($_POST['submit']) ? $_POST['submit'] : null);
    if($action!=null) {
																		
        if($email==null || $password==null) {
            echo "<font style='color:red'>Please insert all text fields!</font><br><br>";
		}

        else {
            $query= "SELECT * FROM staff WHERE email='$email' AND password='$password' AND role = 'Secretary'";
            $result=mysqli_query($con, $query);
            $row = mysqli_fetch_assoc($result);

            if($row['user_id'] != null) {
				session_start();
                $_SESSION['email'] = $email;
                $_SESSION['first_name'] = $row['first_name'];
                $_SESSION['last_name'] = $row['last_name'];
                $_SESSION['role'] = $row['role'];
                $_SESSION['user_id'] = $row['user_id'];
                echo"<script type='text/javascript'>alert('Successfully logged in')</script>";													
                header('Location: index.php');				
            }
            else {
                echo "<script>alert('Incorrect email and/or password');</script>";		
            }
        }
    }
?>

<body>
<div class="container">
	<div class="d-flex justify-content-center h-100">
		<div class="card">
			<div class="card-header">
				<h3>Sign In as Secretary</h3>
			</div>
			<div class="card-body">
				<form action="login.php" method="post">

					<div class="input-group form-group">
						<div class="input-group-prepend">
							<span class="input-group-text"><i class="fas fa-user"></i></span>
						</div>
						<input type="text" name="email" class="form-control" placeholder="Email">
					</div>

					<div class="input-group form-group">
						<div class="input-group-prepend">
							<span class="input-group-text"><i class="fas fa-key"></i></span>
						</div>
						<input type="password" name="password" class="form-control" placeholder="Password">
					</div>

					<div class="form-group">
						<input name="submit" type="submit" value="Login" class="btn float-right login_btn">
					</div>

				</form>
			</div>
			<div class="card-footer">
                <a class="btn login_btn" href="../index.php">Back</a>
			</div>
		</div>
	</div>
</div>
</body>
</html>

<?php include "../includes/login_style.php"; ?>