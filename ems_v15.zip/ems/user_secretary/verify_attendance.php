<?php include "../includes/session.php"; 
?>

<!DOCTYPE HTML>
<html>
<head>
	<?php include "header.php"; ?>

	<!-- For table -->
	<link rel="stylesheet" type="text/css" href="../css/table-style.css" />
	<link rel="stylesheet" type="text/css" href="../css/basictable.css" />
	<script type="text/javascript" src="../js/jquery.basictable.min.js"></script>
	<!-- For table -->

	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/clocklet@0.2.6/css/clocklet.min.css">
	<script src="https://cdn.jsdelivr.net/npm/clocklet@0.2.6"></script>
	<!-- timepicker -->

	<!---datepicker-->
	<?php //include "datepicker_css_js.php"; ?>
	<?php include "new_datepicker.php"; ?>
</head>

<body>

<div class="page-container">
<!--/content-inner-->
<div class="left-content">
	<div class="mother-grid-inner">
		<?php include "header_panel.php"; ?>

		<ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php">Home</a><i class="fa fa-angle-right"></i>Meetings
            <i class="fa fa-angle-right"></i>Verify Attendance</li>
		</ol>
		
		<?php
            include "../includes/connect_db.php";
            $id = (isset($_GET['id']) ? $_GET['id'] : null);
			$title =(isset($_POST['title']) ? $_POST['title'] : null);
			$venue =(isset($_POST['venue']) ? $_POST['venue'] : null);
			$from_date =(isset($_POST['from_date']) ? $_POST['from_date'] : null);
			$to_date =(isset($_POST['to_date']) ? $_POST['to_date'] : null);
			$start_time =(isset($_POST['start_time']) ? $_POST['start_time'] : null);
			$end_time =(isset($_POST['end_time']) ? $_POST['end_time'] : null);
			$agenda =(isset($_POST['agenda']) ? $_POST['agenda'] : null);

            $info_query = "SELECT * FROM meeting WHERE meeting_id = '".$id."'";
            $info_result = mysqli_query($con, $info_query);
            $info_row = mysqli_fetch_assoc($info_result);

			$q_file = "SELECT fileName FROM documents WHERE meeting_id = '$id' ";
			$r_file = mysqli_query($con, $q_file);
			$info_file = mysqli_fetch_assoc($r_file);
			$fileName = $info_file['fileName'];
		?>
		<div class="w3-agile-chat">
				<div class="charts">
					<div class="col-adjust-10">
						<div class="charts-grids widget">
							<h4 class="title">Meeting Details</h4>

                            <form action="meeting_details.php?id=<?php echo $id ?>" method="post">
                                <div class="vali-form">
									<div class="col-md-6 form-group1">
										<label class="control-label">Meeting Title</label>
										<input type="text" name="title" placeholder="Meeting Title" value="<?php echo $info_row['title'] ?>" disabled>
									</div>
									<div class="col-md-6 form-group1">
										<label class="control-label">Venue</label>
										<input type="text" name="venue" placeholder="Venue" value="<?php echo $info_row['venue'] ?>" disabled>
									</div>
                                	<div class="clearfix"></div>
								</div>

								<div class="vali-form vali-form1">
									<div class="col-md-6 form-group1">
										<label class="control-label">From Date</label>
										<input type="text" id="from" name="from_date" value="<?php echo $info_row['from_date']; ?>" disabled>
									</div>

									<div class="col-md-6 form-group1">
										<label class="control-label">To Date</label>
										<input type="text" id="to" name="to_date" value="<?php echo $info_row['to_date']; ?>" disabled>
									</div>
                                	<div class="clearfix"> </div>
								</div>

								<div class="vali-form vali-form1">
									<div class="col-md-6 form-group1">
										<label class="control-label">Start Time</label>
										<input data-clocklet="format: h:mm a" name='start_time' value= "<?php echo $info_row['start_time'] ?>" disabled/>
	                                </div>

	                            	<div class="col-md-6 form-group1">
										<label class="control-label">End Time</label>
										<input data-clocklet="format: h:mm a" name='end_time' value= "<?php echo $info_row['end_time'] ?>" disabled/>
	                            	</div>

	                            	<div class="clearfix"> </div>
                                </div>

                                <div class="vali-form vali-form1">
									<div class="col-md-6 form-group1">
									<label class="control-label">Agenda</label>
									<textarea name="agenda" placeholder="Agenda" disabled><?php echo $info_row['agenda'] ?></textarea>
                                	</div>

                                    <div class="col-md-6 form-group1">
									<label class="control-label">File for Reference</label>
									<div class="clearfix"><br/> </div>
									<?php 
									if($fileName!=null){
										echo "<a target='_blank' href='documents/$fileName'><span class='glyphicon glyphicon-eye-open'></span>&nbspView Uploaded File</a>";
									 }
									 else{
										 ?><input type="file" name="fileToUpload" id="fileToUpload" disabled><?php
									 }
									?>
									
                                	</div>
                                </div>
                                </form>
                                <div class="clearfix"><br/> </div>
								<div class="clearfix"><br> </div>
                            
                            	<!--Start Extension -->

	                        	<h2>Attendees</h2>
	                        	<form name="form1" method="post" action="verify_attendance.php?id=<?php echo $id ?>">
								<table id="table">

								<thead>
									<tr>
									<th>No.</th>
									<th>Staff ID</th>
									<th>Name</th>
									<th>Role</th>
									<th>Response</th>
									<th>Attendance Status</th>
									</tr>
								</thead>

								<tbody>
									<?php
										include "../includes/connect_db.php";
										$id = (isset($_GET['id']) ? $_GET['id'] : null);
										$query = "SELECT * FROM `attendees` WHERE meeting_id = $id";
										$result = mysqli_query($con, $query); 
										if(mysqli_num_rows($result) == 0) {
											echo '<tr class="odd gradeX"><td colspan="8">Record not found</td></tr>';                     
										}
										$i=0;
										echo "<form action='verify_attendance.php?id=$id' method='post'>";
										$att = array();
										while ($row = mysqli_fetch_assoc($result)){
											$staffid=$row['user_id'];
											$att_id=$row['attendee_id'];
											$att[$i]=$att_id;
									?>
											<tr>
											<td><?php echo $i+1 ?></td>
											<input type="hidden" name="attendee_id[]" value="<?php echo $att_id; ?>"/>
											<td><?php echo $staffid; ?></td>
											<?php 
												$sub_query = "SELECT * FROM `staff` where user_id = $staffid ";
												$sub_result = mysqli_query($con, $sub_query);
												$sub_row = mysqli_fetch_assoc($sub_result);
											?>
											<td><?php echo $sub_row['first_name']," ", $sub_row['last_name'] ?></td>
											<td><?php echo $sub_row['role']; ?></td>
											<td><?php echo $row['pre_status']; ?></td>
											<td>

											<select name="status[]">
												<option value="<?php echo $row['act_status']; ?>"><?php echo $row['act_status']; ?></option>
												<option value="Attended">Attended</option>
												<option value="Not Attended">Not Attended</option>
												<option value="Representative Attend">Representative Attend</option>
											</select>

												<input type="hidden" name="id" value= "<?php echo $staffid; ?>"/>
											</td>
											</tr>
									<?php 
										$i+=1;

										}

										if(isset($_POST['update'])){
											$i=0;
											foreach($_POST['status'] as $status){
												$att_id_input  = $att[$i];
												$i = $i + 1;
											    $update_query = "UPDATE attendees SET act_status = '$status' WHERE attendee_id = '$att_id_input' AND meeting_id = '$id'";
											    $update_result=mysqli_query($con, $update_query)or die(mysqli_error($con));

											    if($update_result){
											    	continue;
											    } 
											    else{
											    	echo "<script>alert('Unsuccessful update'); </script>";
											    }
											}
											if($update_result){
										    	echo "<script>alert('Successful update'); </script>";
										    }

										} 
										echo "</form>";
									?>

								</tbody>
								</table>
								<br>

	                        	<!--End Extension -->
                                <div class="col-md-12 form-group">
                                    <a href="attendance.php" class="btn btn-info" name="back">Back</a>
                                    <button class="btn btn-warning" type="submit" name="update" value="update">Confirm</button>
                                </div>
                                </form>
                                <?php

                                	$action =(isset($_POST['submit']) ? $_POST['submit'] : null);
									if($action != null) {
										// $name = $_POST['name'];
									       // loop through all array items
									    foreach($_POST['user_id'] as $value)
									    {
											// minus value by 1 since arrays start at 0
											$item = $value-1;
											//update table
											$sql1 = mysqli_query("UPDATE attendees SET act_status='$status[$item]' WHERE user_id='$value'") or die(mysql_error());
									   	}
									}

                                ?>
                                
                            <div class="clearfix"> </div>
                        

                        	
						</div>
					</div>			
					<div class="clearfix"> </div>	
				</div>
			</div>

<?php include "import_js.php"; ?>

</body>
</html>