<?php
    include "../includes/connect_db.php";
    $id = (isset($_GET['id']) ? $_GET['id'] : null);
    $query = "DELETE FROM `meeting` WHERE meeting_id = '".$id."'";
    $result = mysqli_query($con, $query);

    $att_query = "DELETE FROM `attendees` WHERE meeting_id = '".$id."'";
    $att_result = mysqli_query($con, $att_query);

    $min_query = "DELETE FROM `minutes` WHERE meeting_id = '".$id."'";
    $min_result = mysqli_query($con, $min_query);

    $task_query = "DELETE FROM `task` WHERE meeting_id = '".$id."'";
    $task_result = mysqli_query($con, $task_query);

    $fback_query = "DELETE FROM `feedback` WHERE meeting_id = '".$id."'";
    $fback_result = mysqli_query($con, $fback_query);

    $doc_query = "DELETE FROM `documents` WHERE meeting_id = '".$id."'";
    $doc_result = mysqli_query($con, $doc_query);

    if($result&&$att_result&&$min_result&&$task_result){
        echo "<script>alert('Meeting deleted successfully !');</script>";
        header("Location:index.php");
    }
    else{
    	echo "<script>alert('Data failed to be deleted !');</script>";
    }
?>