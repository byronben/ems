<!--header start here-->
<div class="header-main">

				<!--Logout modal-->
				<div class="modal bs-example-modal-sm" tabindex="-1" role="dialog" aria-hidden="true">
					<div class="modal-dialog modal-sm">
						<div class="modal-content">
						<div class="modal-header"><h4>Logout <i class="fa fa-lock"></i></h4></div>
						<div class="modal-body"><i class="fa fa-question-circle"></i> Are you sure you want to log-off?</div>
						<div class="modal-footer"><a href="logout.php" class="btn btn-primary btn-block">Logout</a></div>
						</div>
					</div>
				</div>
				<!--Logout modal-->

				
				<div class="profile_details w3l">		 
					<ul>
						<li class="dropdown profile_details_drop">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
								<div class="profile_img">	
									<span class="prfil-img"><img src="../images/in4.jpg" alt=""> </span> 
									<div class="user-name">
										<p><?php echo $first_name ?></p>
										<span>Secretary</span>
									</div>
									<i class="fa fa-angle-down"></i>
									<i class="fa fa-angle-up"></i>
									<div class="clearfix"></div>	
								</div>	
							</a>
							<ul class="dropdown-menu drp-mnu">
								<li> <a  data-toggle="modal" data-target=".bs-example-modal-sm"><i class="fa fa-sign-out"></i> Logout</a> </li>
							</ul>
						</li>
					</ul>
				</div>
				<div class="clearfix"> </div>	
			</div>
			<!--header end here-->