<!DOCTYPE HTML>
<html>
<head>
    <title>Electronic Meeting and Minutes System</title>
    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
    <!-- Custom CSS -->
    <link href="css/style.css" rel='stylesheet' type='text/css' />
    <link rel="stylesheet" href="css/morris.css" type="text/css"/>
    <!-- Graph CSS -->
    <link href="css/font-awesome.css" rel="stylesheet"> 
    <!-- jQuery -->
    <script src="js/jquery-2.1.4.min.js"></script>
    <!-- //jQuery -->
    <link href='//fonts.googleapis.com/css?family=Roboto:700,500,300,100italic,100,400' rel='stylesheet' type='text/css'/>
    <link href='//fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
    <!-- lined-icons -->
    <link rel="stylesheet" href="css/icon-font.min.css" type='text/css' />
    <!-- //lined-icons -->
</head> 

<body>
    <div class="container">
        <div class="agile3-grids">	
            <div class="agile-buttons-grids">
            <div class="col-adjust-10">
                <div class="panel1 button-sizes" align="center">
                    <h1>Electronic Meeting and Minutes System</h1>
                    <br><br>
                    <div class="panel-heading">
                        <div class="panel-title pn">
                            <h3 class="mtn mb10 fw400">What do you want to login as ?</h3>
                        </div>
                    </div>
                    <div class="panel-body mtn">
                        <div class="col-md-3">
                            <a class="btn btn-primary" href="user_admin/login.php">Admin</a>
                        </div>
                        <div class="col-md-3">
                            <a class="btn btn-dark" href="user_secretary/login.php">Secretary</a>
                        </div>
                        <div class="col-md-3">
                            <a class="btn btn-success" href="user_chairman/login.php">Chairman</a>
                        </div>
                        <div class="col-md-3">
                            <a class="btn btn-warning" href="user_member/login.php">Member</a>
                        </div>
                    </div>
                </div>
            </div>
            </div>
        </div>
    </div>
</body>
</html>